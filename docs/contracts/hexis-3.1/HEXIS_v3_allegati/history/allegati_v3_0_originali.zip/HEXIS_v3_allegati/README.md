# HEXIS 3.0 — Allegati al piano integrale del 11 settembre 2026

Questi file accompagnano `HEXIS_piano_integrale_v3_2026-09-11.md`. Il piano è completo come specifica; la repository non è stata modificata. I riferimenti eseguibili sono verifiche separate, non una pipeline canonica già integrata.

## Contenuto e autorità

| File | Ruolo |
|---|---|
| `hexis_v3_design.json` | Specifica strutturata: parametri delle 9 celle, 7 blocchi, registro di 18 prefissi/17 documenti, input e cardinalità |
| `corpus_atteso.json` | Conteggi verificati per documento, blocco e codifica; riferimento del gate dati |
| `identita_fonti_verificate.json` | Metadati e hash delle quattro sorgenti bibliografiche controllate in aggiunta |
| `protocol_contract.py` | Contratto eseguibile dei semi, campionamento, rimescolamento e confini |
| `ctw_reference.py` | Copia del nucleo CTW già verificato; riferimento matematico separato |
| `resolved_diagnostics.py` | Definizione operativa della massa risolta e della sua profondità |
| `score_contract.py` | Riferimenti minimi per JSD e pesi descrittivi |
| `validate_contract.py` | Coerenza della configurazione, fixture e pilot opzionale su dati reali |
| `validate_diagnostics.py` | 765 storie e controesempio sulla cancellazione impropria delle CE di radice |
| `validate_scores.py` | JSD, supporto con zeri, contributi, pesi e quattro termini di Q |
| `contract_validation.json` | Risultato effettivo del nuovo contratto, inclusi 16 fit reali e 84 valutazioni probe |
| `diagnostics_validation.json`, `scores_validation.json` | Risultati effettivi delle altre verifiche supplementari |
| `verifiche_CTW_precedenti.zip` | Archivio già consegnato: sorgenti sintetiche, enumerazione, protocollo pre-pilot, ledger e risultati |
| `verdetto_CTW_precedente.md`, `verifica_comparata_precedente.md` | Traccia del giudizio che precede la specifica v3 |
| `package_validation.json` | Esito della verifica finale di cardinalità, formule operative, fonti e integrità del repository |
| `SHA256SUMS.json` | Hash degli altri componenti, escluso questo stesso inventario |

`hexis_v3_design.json` è un contratto di destinazione e non può essere passato alla vecchia CLI come se fosse una configurazione compatibile. La conversione allo schema applicativo avviene nella migrazione V0–V2. Il codice di riferimento non implementa tutte le validazioni dei tipi, la CLI, i manifest e gli output finali prescritti dal piano.

Il campo storico `weighted_depth` restituito da `ctw_reference.py` resta nei risultati di riferimento per tracciabilità; non è la diagnostica scientifica v3. Quest’ultima è definita in `resolved_diagnostics.py`. Nessun modulo del progetto deve importare questi file come scorciatoia al superamento dei gate.

## Riprodurre le verifiche supplementari

Ambiente effettivo: Python 3.12.14, NumPy 2.3.5. Il contratto supplementare usa solo la libreria standard e NumPy. Non importare moduli da una cartella `candidates/`.

Estrarre il pacchetto in una cartella nuova, conservando questa copia come evidenza. Nella copia di esecuzione:

```bash
python -B validate_contract.py --output rerun_contract
python -B validate_diagnostics.py
python -B validate_scores.py
```

I due ultimi comandi scrivono i rispettivi JSON nella cartella dello script. Per non sovrascrivere l’evidenza originaria, eseguirli soltanto nella copia di lavoro.

Per ripetere i 16 fit reali, acquisire i tre CoNLL-U dal commit UD e dagli hash presenti nel JSON. L’archivio CTW precedente include `prepare_data.py` e le istruzioni per questa acquisizione. Passare la directory dei file, per esempio:

```bash
python -B validate_contract.py --raw-dir raw/UD_Ancient_Greek-Perseus --output rerun_real
```

Non occorre clonare HEXIS per questo controllo. I dati non sono inclusi nel pacchetto. I 14 fit C0 formano sette coppie originale/rimescolato al primo seme della nuova convenzione; una coppia aggiuntiva verifica `bound`. Non sono il run scientifico finale da 1.400 fit. Il validatore non calcola il contrasto tra gruppi.

## Interpretazione degli esiti

PASS significa che i casi effettivamente eseguiti soddisfano i controlli. Non significa assenza universale di bug, correttezza già dimostrata dell’implementazione futura o dimostrazione di un effetto metrico. Il piano stabilisce i test che il codice integrato dovrà superare. I dati, il codice del repository e gli allegati originali non sono stati modificati.
