# HEXIS CTW feasibility audit — fixed before model experiments

Repository 852644b6917790877c7b2ca5df2e76b17829d87c is read-only.
User 2026-09-11 authorizes CTW change and the proposed verification. These are
isolated feasibility experiments, including real-data pilots, not production
results or a ratified replacement of repository gates.

Candidate: multi-symbol CTW, symmetric Dirichlet a=0.5 per outcome,
maximum depth D=8, prior stop probability rho=0.5. Store log(stop) and
log(split) separately. No k_min and no monotone selector. Empty subtrees
integrate to one. Context-only BOS=-1 is a forced leaf; it is never an outcome.
Each sentence/isolated sampled fragment resets history. All training symbols
are counted; primary evaluation has at least four retained predecessors.
Frozen local parameters AND posterior model weights; evaluation history advances.
Mathematical status: standard CTW recursion, extended to forced BOS leaves;
this conditional sentence likelihood extension requires its own proof/checks.

Before looking at real predictive results:
1. Exact enumeration of all small context trees versus recursive evidence and
   frozen predictions; independent sequential KT-product implementation.
2. Exhaustive probability normalization for small alphabets, unseen outcomes,
   unseen histories, D=0, empty training, short sentences, reset, permutation
   invariance, read-only evaluation and sentence order invariance.
3. IID4, cycle3, order1 p(stay)=.8, lag2 binary p(copy)=.9, true variable memory,
   all at n_train=53304 with independent n_test=100000; five fixed seeds.
   Targets: IID near2; cycle<.02; order1 near.721928; lag2 near.468996
   (absolute tolerance .03 for the last two). No favorable-seed selection.
4. Alphabet106 IID and lag2 full-uniform alphabet; also alphabet106 with a
   frequent binary core and rare symbols, including depth2 signals. Report
   failure, if any: these tests measure different amounts of available support.
5. Parameter sensitivity fixed in advance: a=1/m; rho=.9;
   literature split prior 2^(-(m-1)), computed directly in log space;
   D=6 and D=12; half training size. No tuning on prose/verse contrast.
6. Audit pinned raw Greek bytes; independently construct symbol sequences,
   whole-sentence sampler plus at most one contiguous final fragment per block,
   source ordinal order, exact q=8884, seven block exclusion folds.
7. Real pilot: seven folds, initially one fixed seed C0, only pooled predictive
   and resource diagnostics. Extend to a second seed and specified sensitivity
   cells to resolve concrete questions. Do not compute regime contrast, rank,
   p-values or use labels in the model/sampling routines.
8. Synthetic 7-block/20-seed pipeline integration; leakage and pairing checks.
9. Report fit/evaluation time, process peak RSS, node counts, unseen contexts,
   effective depth mixture, costs projected to the previously contemplated700fits.
   Verify unchanged repository tracked bytes and git status at completion.

Evidence must distinguish finite-sample performance, exact mathematical identity,
engineering feasibility and scientific interpretation. No claim of universal
success, grammar recovery, absence of all bugs, or production integration.
