# Mathematical contract of the audit prototype

This is an isolated feasibility candidate, not an amendment applied to HEXIS.

## Outcomes and conditional histories

The outcome alphabet A has m ordinary morphosyntactic symbols. Each training
sentence or isolated sampled fragment is a new stream. For target x_t, history
contains the previous at most D symbols, newest first. If fewer than D exist,
append a context-only BOS marker. BOS terminates a branch and is never predicted.
For the separate boundary sensitivity, a supplied SEP marker may occur in the
history between provably adjacent source sentences; SEP is never an outcome.
The history can continue through SEP but never through BOS. Segmentation and
the separator schedule are treated as externally supplied design information.

At every nonterminal node s, every target counted at s goes to exactly one child:
an older ordinary symbol, SEP where present, or BOS when its history ends.
Consequently n_s(a)=sum_child n_child(a). Unlike naive truncated suffix counting,
sentence-initial observations do not disappear when considering a split.

## Integrated evidence and prior

An independent symmetric Dirichlet(a,...,a), a>0, is placed on the outcome
distribution of every model leaf. A free node below D stops with probability rho
and splits with probability 1-rho. At D and at BOS, stopping is forced.
This recursive process defines a proper prior on a finite set of trees: induction
gives prior mass rho+(1-rho)*product_child(1)=1 at each free node.

For a node s with count vector n_s and N_s=sum_a n_s(a),

E_s = Gamma(m*a)/Gamma(N_s+m*a) * product_a Gamma(n_s(a)+a)/Gamma(a).

W_s = E_s at a forced leaf; otherwise
W_s = rho*E_s + (1-rho)*product_child W_child.

Induction on depth proves that W_root equals the sum over all allowed context
trees of prior(tree)*integrated_likelihood(data|tree). Children partition the
observations, and independent Dirichlet parameters factor across leaves. Empty
subtrees have E=W=1 and may be omitted without changing this sum. All counts use
all training outcomes, including those at the beginning of streams.

This is the standard CTW evidence recursion applied to a specified conditional
context tree with forced boundary leaves. The exact finite-tree identity extends
by this proof. The stationary-source redundancy/consistency theorems for the
original paper are NOT automatically claimed for this segmented heterogeneous
corpus. The BOS convention is an explicit operational adaptation, not a claim
that the paper prescribes HEXIS sentence handling.

## Frozen prediction

w_s=rho*E_s/W_s for a free node; w_s=1 at a forced leaf.
p_s(a)=(n_s(a)+a)/(N_s+m*a).

For a supplied query history h whose next edge is c,
q_s(a|h)=w_s*p_s(a)+(1-w_s)*q_c(a|h).

An entirely unobserved branch has predictive distribution 1/m under this
symmetric prior. All terms are nonnegative and sum to one. The recursion computes
sum_tree posterior(tree|TRAIN)*posterior_mean_leaf_probability(a|TRAIN,tree,h).
Counts AND weights stay fixed across the entire evaluation corpus. Only h moves
with the already observed test symbols. The frozen product of these predictions
is a proper conditional code, but is NOT the online CTW marginal-likelihood ratio
obtained by updating the posterior on every new evaluation outcome.

The root comparator is p_root from the same training counts and same a. Evaluate
root and CTW on exactly the same held-out target coordinates. Their average loss
difference is operational predictive gain, not a direct unbiased estimator of
the language's entropy rate or mutual information. Gain may be negative.

## Numerics and limits

Store log(E), log(W), log(rho), log(1-rho) separately and use log-sum-exp.
At m=106 the literature suggestion 1-rho=2^(-105) is positive, but constructing
rho=1-2^(-105) in binary64 rounds to1. Computing the log split probability
directly avoids disabling splitting by numerical accident.

In the reported diagnostics the BOS edge contributes zero past tokens. A mixed
context depth is a posterior-weighted path length, not a selected depth, a true
Markov order, grammatical depth or cognitive memory. SEP, when used, counts as
one history event; its diagnostic scale differs from reset mode.

No monotone veto, k_min cutoff, gamma threshold or additive custom model penalty
is present. rho and Dirichlet a have distinct roles and must not share a config
name. D remains a fixed maximum, not an assertion of linguistic finite memory.

## Compatibility decisions needed in the later update plan

Retire the old monotone/argmax selector cells, k_min, gamma, and selected-depth
claims. Give rho and a separate explicit names. Replace training-order seed
variation by a deterministic order (the integrated evidence is order invariant).
Pair sampling across numeric hyperparameter cells. Keep root JSD as descriptive
R1, computed from frozen root distributions on a declared common alphabet.

For the boundary sensitivity, the audit uses context-only SEP with lexical-only
outcome alphabet. This deliberately replaces the earlier ambiguous convention
where '#' was in the smoothing alphabet but said never to be a target. The two
conventions are not equivalent and must never be silently interchanged.

The diagnostic trials use the authorized finite-corpus scope, not the old
confirmatory Greek/Latin design. Repo gates and documents require an explicit
later migration; no current production gate has been declared passed here.
