# Verifiche CTW per HEXIS — 11 settembre 2026

Prototipo di verifica, separato dalla repository. Non è una patch di produzione,
non modifica il piano scientifico ratificato e non produce test di significatività.
Il rapporto esterno riassume il verdetto; MATHEMATICAL_CONTRACT.md specifica
formule, confini, predizione congelata e limiti delle garanzie.

## Riproduzione

Estrarre l'archivio in una directory nuova. `ctw_validation/` e
`corpus_check.json` devono trovarsi nella stessa directory padre.
Python verificato: 3.12.14. Dipendenze: requirements.txt. Nessuna GPU.

Le prove puramente matematiche e sintetiche non richiedono GitHub né i treebank:

```bash
python -m venv .venv
.venv/bin/pip install -r ctw_validation/requirements.txt
.venv/bin/python ctw_validation/verify_exact.py
.venv/bin/python ctw_validation/verify_synthetic.py
.venv/bin/python ctw_validation/verify_heterogeneity.py
```

Per riprodurre anche il pilot reale serve una copia autorizzata di HEXIS nella
directory sorella `HEXIS`, al commit
`852644b6917790877c7b2ca5df2e76b17829d87c`. Clonare in una directory nuova,
senza cambiare una copia di lavoro esistente. Lo script legge solo config,
registro proposto e PROVENANCE dalla copia. Non importa moduli della repository
e non importa il candidato in quarantena.

`prepare_data.py` scarica i tre file UD al commit fissato e verifica i loro hash.
Non sovrascrive file preesistenti e fallisce se un hash non coincide.
I dati originali sono distribuiti dagli autori del treebank con la licenza
indicata nella provenienza (CC BY-NC-SA 2.5); non sono inclusi nell'archivio.

```bash
.venv/bin/python ctw_validation/prepare_data.py
.venv/bin/python ctw_validation/verify_pipeline.py
.venv/bin/python ctw_validation/pilot.py --cell C0 --seeds 20
.venv/bin/python ctw_validation/pilot.py --cell a_total1
.venv/bin/python ctw_validation/pilot.py --cell rho09
.venv/bin/python ctw_validation/pilot.py --cell rho_literature
.venv/bin/python ctw_validation/pilot.py --cell q_half
.venv/bin/python ctw_validation/pilot.py --cell D6
.venv/bin/python ctw_validation/pilot.py --cell D12
.venv/bin/python ctw_validation/pilot.py --cell oth
.venv/bin/python ctw_validation/pilot.py --cell upos
.venv/bin/python ctw_validation/pilot.py --cell bound
.venv/bin/python ctw_validation/verify_shuffle.py
.venv/bin/python ctw_validation/benchmark.py
```

Gli script scrivono soltanto risultati e log nella propria directory di verifica;
le nuove esecuzioni sostituiscono i file di risultato del prototipo. Estrarre una
seconda copia se si desidera conservare i risultati originali per confronto.
Le durate e il picco di memoria dipendono dal computer. I punteggi devono
coincidere entro l'errore numerico dichiarato, con dati, dipendenze e semi fissati.

## File di evidenza

- exact_results.json: enumerazione completa, normalizzazione, congelamento,
  invarianza alle etichette dei simboli e all'ordine degli stream, identità prequenziale.
- pipeline_results.json: 140 fit su sette blocchi sintetici e 20 semi,
  esclusione held-out, budget esatto, adiacenza, semi e separatori.
- synthetic_results.json: 61 valutazioni, cinque repliche per sorgente analitica
  piccola e tre per sorgente con alfabeto106. Gli esperimenti con a/rho diversi
  riusano i conteggi, non richiedono nuovi campioni.
- pilot_C0.json: 140 fit reali, con metadati, tempi, diagnostiche e punteggi
  dei singoli blocchi; nessun contrasto fra gruppi.
- pilot_*.json: nove sensibilità, sette fold e un seme ciascuna.
- ledger_*.json: provenienza dei campioni per il primo seme di ogni cella.
- heterogeneity_results.json: guadagno spurio rispetto a un'interpretazione
  come dipendenza interna, su testi i.i.d. con marginali differenti.
- shuffle_results.json: controllo con rimescolamento entro stream/frase;
  tre semi sintetici e un pilot reale sui sette fold. Non è una distribuzione
  nulla calibrata né una procedura di inferenza.
- benchmark_results.json: profiling isolato, simboli non osservati e memoria.
- pilot_positions_example.npz: sei vettori numerici per un fold, senza testo.
- completion.json: integrità dei120 file tracciati e riepilogo dell'audit.

## Fonte metodologica primaria

Kontoyiannis et al., *Bayesian context trees: modelling and exact inference
for discrete time series*, versione3, 2022:
https://arxiv.org/abs/2007.14900v3

Letture pertinenti: §§2.2–2.3, algoritmo3.1, §3.6, appendiceD.
La gestione BOS/SEP è un adattamento condizionale esplicito, dimostrato nel
contratto e verificato per enumerazione; non viene attribuita testualmente
all'articolo. Il PDF della fonte non è redistribuito in questo archivio.

## Scoperte che il nuovo piano deve recepire

1. CTW risolve il veto locale del selettore precedente, non la scarsità di dati.
2. Con106 simboli l'informazione profonda recuperata può restare limitata.
3. Guadagno su un modello comune non equivale a informazione mutua interna al
   testo: serve il controllo sull'ordine se si vuole una lettura sequenziale.
4. rho, pseudoconteggio a e profondità sono scelte distinte; i nuovi parametri
   non vanno confusi con beta/gamma del vecchio metodo.
5. Il piano dovrà ratificare confini e output prima dell'implementazione canonica.
