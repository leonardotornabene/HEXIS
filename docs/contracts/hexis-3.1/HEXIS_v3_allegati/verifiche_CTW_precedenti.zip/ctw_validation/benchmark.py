"""Isolated real-data profiling; no group comparison."""
import json,resource,time,platform,hashlib
from pathlib import Path
import numpy as np
from ctw import CTW
from pilot import load_data,fold_data,streams
ROOT=Path(__file__).resolve().parent

def main():
    blocks,probe,meta=load_data();rows=[]
    for held in sorted(blocks):
        tr,te,ledger=fold_data(blocks,held,0,8884)
        t0=time.perf_counter();model=CTW(106,8).fit(tr);fit=time.perf_counter()-t0
        t0=time.perf_counter();res=model.evaluate(te,positions=True);evaluation=time.perf_counter()-t0
        t0=time.perf_counter();pr=model.evaluate(streams(probe));probe_s=time.perf_counter()-t0
        counts=model.nodes[0].counts
        unseen=sum(counts.get(x,0)==0 for seq in te for x in seq[4:])
        rows.append({'held':held,'fit_s':fit,'eval_s':evaluation,'probe_s':probe_s,'n_eval':res['n_eval'],
                     'root_seen_symbols':len(counts),'unseen_outcome_count':unseen,'unseen_outcome_rate':unseen/res['n_eval'],
                     'mean_unseen_branch_weight':res['unseen_branch_weight'],'position_array_bytes':sum(a.nbytes for a in res['positions'].values()),
                     'peak_rss_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024})
        del model
    p=ROOT/'pilot_positions_example.npz'
    out={'rows':rows,'example_compressed_position_bytes':p.stat().st_size,'python':platform.python_version(),'numpy':np.__version__}
    (ROOT/'benchmark_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

if __name__=='__main__':main()
