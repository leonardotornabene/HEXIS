"""Label-free CTW pilot and exact-budget sampling; independent raw parsing."""
from pathlib import Path
from collections import Counter,defaultdict
import math, json, hashlib, time, gc, resource, zlib, argparse, platform
import numpy as np
import yaml
from ctw import CTW
ROOT=Path(__file__).resolve().parent; AUDIT=ROOT.parent; REPO=AUDIT/'HEXIS'
BLOCKS=json.loads((AUDIT/'corpus_check.json').read_text())['blocks']

def load_data(variant='ud23'):
    cfg=yaml.safe_load((REPO/'config/default.yaml').read_text())['alphabet']
    reg=yaml.safe_load((REPO/'docs/g1_registry_proposal.yaml').read_text())
    records=[]; symbols=set(); hashes={}; seen=set()
    for p in sorted((AUDIT/'raw/UD_Ancient_Greek-Perseus').glob('*.conllu')):
      b=p.read_bytes(); hashes[p.name]=hashlib.sha256(b).hexdigest()
      for chunk in b.decode().strip().split('\n\n'):
        meta={}; rows=[]
        for line in chunk.splitlines():
            if line.startswith('# ') and ' = ' in line:
                k,v=line[2:].split(' = ',1);meta[k]=v
            elif line and not line.startswith('#'):
                f=line.split('\t')
                if f[0].isdigit(): rows.append(f)
        sid=meta['sent_id']; assert sid not in seen;seen.add(sid)
        pref,order=sid.rsplit('@',1);rr=reg[pref]
        if rr['regime']=='EXCLUDED': continue
        seq=[];coordinates=[]
        for row in rows:
            u=cfg['upos_map'].get(row[3],row[3]);d=row[7].lower().split(':')[0]
            if u not in cfg['upos_keep']: continue
            if variant!='ud23_oth' and d not in cfg['deprel_keep']:continue
            s=u if variant=='upos_only' else u+':'+(d if d in cfg['deprel_keep'] else 'oth')
            seq.append(s);symbols.add(s);coordinates.append(int(row[0]))
        records.append({'doc':rr.get('canonical_doc_id',pref),'sid':sid,
             'source_order':(rr.get('part_order',0),int(order)),'seq':seq,'coords':coordinates})
    expected={r['file']:r['sha256'] for r in json.loads((AUDIT/'corpus_check.json').read_text())['source_hashes']}
    assert hashes==expected
    provenance=(REPO/'data/raw/PROVENANCE.md').read_text()
    assert all(h in provenance for h in hashes.values())
    alph=sorted(symbols); ids={s:i for i,s in enumerate(alph)}
    bydoc=defaultdict(list)
    for r in records:
        r['seq']=[ids[s] for s in r['seq']]; bydoc[r['doc']].append(r)
    for dd,ss in bydoc.items():
        ss.sort(key=lambda r:r['source_order'])
        for i,r in enumerate(ss):r['source_rank']=i
    blocks={f'B{i}':[r for d in b['docs'] for r in bydoc[d]] for i,b in enumerate(BLOCKS)}
    primary_docs={d for b in BLOCKS for d in b['docs']}
    probe=[r for d,ss in bydoc.items() if d not in primary_docs for r in ss]
    assert len(probe)>0
    meta={'variant':variant,'alphabet':alph,'m':len(alph),'hashes':hashes,
          'blocks':{b:{'tokens':sum(len(r['seq']) for r in ss),'eligible':sum(max(0,len(r['seq'])-4) for r in ss),'sentences':len(ss)} for b,ss in blocks.items()},
          'probe_tokens':sum(len(r['seq']) for r in probe),'probe_eligible':sum(max(0,len(r['seq'])-4) for r in probe)}
    return blocks,probe,meta

def seed_for(seed,fold,block,substream):
    # Cells are deliberately absent: hyperparameter sensitivities reuse the data.
    key=f'ctw_pilot_v1|seed={seed}|fold={fold}|block={block}|{substream}'
    return 20260706 ^ zlib.crc32(key.encode())

def sample(ss,q,seed,fold,block):
    nonempty=[r for r in ss if r['seq']]
    if sum(len(r['seq']) for r in nonempty)<q:raise ValueError('budget exceeds block')
    perm=np.random.default_rng(seed_for(seed,fold,block,'sample')).permutation(len(nonempty))
    seg_rng=np.random.default_rng(seed_for(seed,fold,block,'segment'))
    chosen=[];remaining=q
    for ii in perm:
        if remaining==0:break
        r=nonempty[int(ii)]; size=min(len(r['seq']),remaining)
        start=int(seg_rng.integers(len(r['seq'])-size+1)) if size<len(r['seq']) else 0
        chosen.append({**r,'seq':r['seq'][start:start+size],'coords':r['coords'][start:start+size],
                       'start':start,'end':start+size,'fragment':size<len(r['seq'])})
        remaining-=size
    assert remaining==0 and sum(r['fragment'] for r in chosen)<=1
    assert len({r['sid'] for r in chosen})==len(chosen)
    return chosen

def streams(records,bound=False):
    if not bound:return [r['seq'] for r in records if r['seq']]
    ordered=sorted(records,key=lambda r:(r['doc'],r['source_rank']))
    out=[];last=None
    for r in ordered:
        if not r['seq']:last=None;continue
        adjacent=last is not None and r['doc']==last['doc'] and r['source_rank']==last['source_rank']+1
        # Consecutive retained ranks alone are insufficient across source-id gaps or parts.
        adjacent=adjacent and r['source_order'][0]==last['source_order'][0] and r['source_order'][1]==last['source_order'][1]+1
        adjacent=adjacent and not r.get('fragment',False) and not last.get('fragment',False)
        if adjacent:out[-1].extend([-2]+r['seq'])
        else:out.append(list(r['seq']))
        last=r
    return out

def fold_data(blocks,held,seed,q,bound=False):
    chosen=[];ledger={}
    for b,ss in sorted(blocks.items()):
        if b==held:continue
        cc=sample(ss,q,seed,held,b);chosen.extend(cc)
        ledger[b]=[{'sid':r['sid'],'start':r['start'],'end':r['end'],'fragment':r['fragment']} for r in cc]
    held_ids={r['sid'] for r in blocks[held]}
    assert not held_ids.intersection(r['sid'] for r in chosen)
    train=streams(chosen,bound);test=streams(blocks[held],bound)
    assert sum(sum(x>=0 for x in s) for s in train)==q*(len(blocks)-1)
    # No order randomization needed: integrated Dirichlet evidence is invariant to stream permutation.
    return train,test,ledger

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--cell',default='C0');ap.add_argument('--seeds',type=int,default=1);args=ap.parse_args()
    cell=args.cell
    var={'oth':'ud23_oth','upos':'upos_only'}.get(cell,'ud23')
    blocks,probe,meta=load_data(var);m=meta['m'];q=4442 if cell=='q_half' else 8884
    D={'D6':6,'D12':12}.get(cell,8);a=1/m if cell=='a_total1' else .5
    rho=.9 if cell=='rho09' else .5;logsp=-(m-1)*math.log(2) if cell=='rho_literature' else None
    bound=cell=='bound';rows=[]
    output={'cell':cell,'metadata':meta,'environment':{'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform()},'rows':rows}
    for seed in range(args.seeds):
      for held in sorted(blocks):
        t0=time.perf_counter();train,test,ledger=fold_data(blocks,held,seed,q,bound);sampler_s=time.perf_counter()-t0
        t0=time.perf_counter();model=CTW(m,D,a,rho,logsp).fit(train);fit_s=time.perf_counter()-t0
        fingerprint=model.fingerprint()
        t0=time.perf_counter();res=model.evaluate(test,positions=True);eval_s=time.perf_counter()-t0
        pos=res.pop('positions')
        # Archive compact per-position numeric evidence for the first C0 fold only.
        if cell=='C0' and seed==0 and held=='B0':np.savez_compressed(ROOT/'pilot_positions_example.npz',**pos)
        probe_s=0.;pr=None
        if cell=='C0':
            t0=time.perf_counter();pr=model.evaluate(streams(probe));probe_s=time.perf_counter()-t0
        assert fingerprint==model.fingerprint()
        # Same eligible lexical coordinates across all boundaries / depths for this representation.
        assert res['n_eval']==meta['blocks'][held]['eligible']
        buckets={}
        for name,mask in [('past4_7',(pos['past']>=4)&(pos['past']<8)),('past8plus',pos['past']>=8)]:
            if mask.any():buckets[name]={'n':int(mask.sum()),'gain':float((pos['root_loss'][mask]-pos['loss'][mask]).mean()),'weighted_depth':float(pos['weighted_depth'][mask].mean())}
        row={'held':held,'seed':seed,'sampler_s':sampler_s,'fit_s':fit_s,'eval_s':eval_s,'probe_s':probe_s,
             'n_streams':len(train),'boundaries':sum(s.count(-2) for s in train),
             'sample_hash':hashlib.sha256(json.dumps(ledger,sort_keys=True).encode()).hexdigest(),
             'model_hash':fingerprint,**res,**model.diagnostics(),'past_buckets':buckets,
             'peak_rss_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
        rows.append(row)
        (ROOT/f'pilot_{cell}.json').write_text(json.dumps(output,indent=2))
        if seed==0:(ROOT/f'ledger_{cell}_{held}.json').write_text(json.dumps(ledger,indent=2))
        print(cell,seed,held,'fit',round(fit_s,2),'eval',round(eval_s,2),'CE',round(res['ce'],5),'gain',round(res['gain'],5),'depth',round(res['weighted_depth'],3),'RSS',round(row['peak_rss_MiB']),flush=True)
        del model,pos,train,test;gc.collect()

if __name__=='__main__':main()
