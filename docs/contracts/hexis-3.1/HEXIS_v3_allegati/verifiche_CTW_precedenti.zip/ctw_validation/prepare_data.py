"""Optional reproduction helper. Fetch immutable UD bytes without overwriting files."""
from pathlib import Path
import json,hashlib,urllib.request
ROOT=Path(__file__).resolve().parent.parent
PIN='37837c7a3c592c9563f8c51cc63344b87247f8a5'
if __name__=='__main__':
    records=json.loads((ROOT/'corpus_check.json').read_text())['source_hashes']
    dest=ROOT/'raw/UD_Ancient_Greek-Perseus';dest.mkdir(parents=True,exist_ok=True)
    for rec in records:
        path=dest/rec['file']
        if path.exists():data=path.read_bytes()
        else:
            url=f'https://raw.githubusercontent.com/UniversalDependencies/UD_Ancient_Greek-Perseus/{PIN}/{rec["file"]}'
            with urllib.request.urlopen(url,timeout=60) as response:data=response.read()
        if hashlib.sha256(data).hexdigest()!=rec['sha256']:raise ValueError(f'Hash mismatch: {path}')
        if not path.exists():
            with path.open('xb') as f:f.write(data)
        print(path.name,'verified')
