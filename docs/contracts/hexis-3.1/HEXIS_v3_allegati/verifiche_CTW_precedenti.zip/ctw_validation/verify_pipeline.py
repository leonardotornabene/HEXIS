"""Meaningful boundary, leakage, sampling and full synthetic pipeline checks."""
import json,math,itertools,hashlib
from pathlib import Path
import numpy as np
from ctw import CTW
from pilot import sample,streams,fold_data,seed_for,load_data
from verify_exact import trees,leaf_for

def main():
    out={};rng=np.random.default_rng(338);blocks={}
    for b in range(7):
        rr=[]
        for i in range(20):
            seq=rng.integers(4,size=int(rng.integers(0,30))).tolist()
            rr.append({'doc':f'd{b}','sid':f'd{b}@{i}','seq':seq,'coords':list(range(len(seq))),
                       'source_order':(0,i),'source_rank':i})
        blocks[f'B{b}']=rr
    score_hashes=[];fits=0
    ids=[seed_for(s,f'B{f}',f'B{b}',st) for s in range(20) for f in range(7) for b in range(7) if b!=f for st in ['sample','segment']]
    assert len(ids)==len(set(ids));out['distinct_derived_seeds']=len(ids)
    for seed in range(20):
      for held in blocks:
        tr,te,led=fold_data(blocks,held,seed,110);mod=CTW(4,3).fit(tr)
        score=mod.evaluate(te);fits+=1
        before=mod.fingerprint(); score2=mod.evaluate(te[::-1])
        assert abs(score['ce']-score2['ce'])<1e-12 and before==mod.fingerprint()
        # Labels are not accepted by the model or sampling API; changing external metadata does nothing.
        metadata1={b:'HEX' if b in ['B0','B1'] else 'PROSE' for b in blocks}
        metadata2={b:'PROSE' if v=='HEX' else 'HEX' for b,v in metadata1.items()}
        assert metadata1!=metadata2
        tr2,te2,led2=fold_data(blocks,held,seed,110)
        assert tr==tr2 and te==te2 and led==led2
        score_hashes.append(hashlib.sha256(json.dumps(score,sort_keys=True).encode()).hexdigest())
    out['synthetic_fits']=fits
    # q_half uses the same whole-sentence prefix, with only the terminal fragment allowed to differ.
    for b,ss in blocks.items():
        full=sample(ss,110,1,'B0',b);half=sample(ss,55,1,'B0',b)
        assert [r['sid'] for r in half]==[r['sid'] for r in full[:len(half)]]
    # Real raw audits are label-free after construction and frozen to independently checked hashes.
    _,_,meta=load_data();out['real_alphabet']=meta['m'];assert meta['m']==106
    # Source adjacency, not consecutive subset ranks. Empty or omitted source sentences break runs.
    def rec(i,seq,fragment=False,doc='a'):
        return {'doc':doc,'sid':f'{doc}@{i}','seq':seq,'coords':list(range(len(seq))),
                'source_order':(0,i),'source_rank':i,'fragment':fragment}
    records=[rec(0,[0,1]),rec(1,[]),rec(2,[1,0]),rec(3,[0,1]),rec(5,[1,1]),rec(6,[0],True),rec(7,[1]),rec(0,[0],doc='b')]
    ss=streams(records,True)
    assert ss==[[0,1],[1,0,-2,0,1],[1,1],[0],[1],[0]]
    gap1,gap2=rec(0,[0]),rec(1,[1]);gap2['source_order']=(0,2)
    assert streams([gap1,gap2],True)==[[0],[1]]
    out['boundary_adjacency_pass']=True
    # Separator is context-only and does not change root training count or output vocabulary.
    t=CTW(2,3).fit(ss);assert t.nodes[0].n==11 and all(-2 not in n.counts for n in t.nodes)
    for nd in t.nodes:
        if not nd.terminal:
            assert nd.n==sum(t.nodes[j].n for j in nd.children.values())
    for h in [[0,-2,1],[-2],[1,0,-2]]: assert abs(sum(t.predict(h,x) for x in range(2))-1)<1e-12
    # Evaluation eligibility resets at separator, model history retains it.
    tt=CTW(2,3).fit([[0,1]*20]);res=tt.evaluate([[0,1,0,1,0,-2,1,0,1,0,1]],min_past=4)
    assert res['n_eval']==2
    # Exact two-level context-tree enumeration including separator and BOS branch.
    seqs=[[0,1,-2,1,0],[1,-2,0,1]];m=2;D=2;a=.5;rho=.5
    def alltrees(path=()):
        if len(path)==D or (path and path[-1]==-1):return [(1.,(path,))]
        out=[(rho,(path,))]
        for comb in itertools.product(*(alltrees(path+(j,)) for j in [-2,-1,0,1])):
            out.append(((1-rho)*math.prod(c[0] for c in comb),sum((c[1] for c in comb),())))
        return out
    z=0.;models=[]
    for prior,leaves in alltrees():
        counts={l:[0,0] for l in leaves};p=prior
        for s in seqs:
            for i,x in enumerate(s):
                if x==-2:continue
                c=counts[leaf_for(leaves,s[:i],D)];p*=(c[x]+a)/(sum(c)+m*a);c[x]+=1
        z+=p;models.append((p,leaves,counts))
    ct=CTW(2,D).fit(seqs);err=abs(math.log(z)-ct.nodes[0].lw);assert err<1e-12
    maxerr=0
    for h in [[],[0],[-2],[0,-2],[-2,1],[1,0]]:
      for x in range(2):
        p=sum(w*(c[leaf_for(l,h,D)][x]+a)/(sum(c[leaf_for(l,h,D)])+m*a) for w,l,c in models)/z
        maxerr=max(maxerr,abs(p-ct.predict(h,x)))
    assert maxerr<1e-12
    out.update({'boundary_evidence_error':err,'boundary_prediction_error':maxerr,'boundary_models':len(models),'status':'PASS',
                'scores_digest':hashlib.sha256(''.join(score_hashes).encode()).hexdigest()})
    Path(__file__).with_name('pipeline_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

if __name__=='__main__':main()
